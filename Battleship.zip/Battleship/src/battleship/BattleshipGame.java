package battleship;
import java.util.Scanner;

// By Julian Quiros

// Make sure only input possible is numbers

public class BattleshipGame {
	Ocean ocean = new Ocean();
	
	public static void main(String[] args) {
		Ocean ocean = new Ocean();
		Scanner reader = new Scanner(System.in);
		welcomeMessage();
		ocean.print();
		ocean.placeAllShipsRandomly();
		int over = 0;
		int totalShots = 0;
		while (over == 0) {
			System.out.println("Enter a desired row to fire at: ");
			int desiredRow = reader.nextInt();
			System.out.println("Enter a desired column to fire at: ");
			int desiredColumn = reader.nextInt();
			ocean.shootAt(desiredRow, desiredColumn);
			totalShots += 1;
			//Ship bullseye = ships[desiredRow][desiredColumn];
			if (ocean.shootAt(desiredRow, desiredColumn) == true) {
				System.out.println("You have hit a ship");
			}
			else {
				System.out.println("You missed.");
			}
			//if (bullseye.isSunk() == true) {
				//System.out.println("You have sunk " + bullseye.getShipType());
			//}
			ocean.print();
			if (ocean.isGameOver() == true) {
				over = 1;
			}
			else {
				over = 0;
			}
		}
		System.out.println("Congratulations you have won");
		System.out.println("You took " + totalShots + " total shots");
		int restart = 0;
		while (restart == 0) {
			System.out.println("Would you like to play again? (Y or N) ");
			String playAgain = reader.next();
			if (playAgain == "Y") {
				//restart game
				restart = 1;
			}
			if (playAgain == "N") {
				System.out.println("Thanks for playing!");
				restart = 1;
			}
			else {
				System.out.println("Incorrect input, please try again.");
				restart = 0;
			}
		}
		ocean.print();

	}
	
	/**
	 * Prints out the Welcome Message and instructions.
	 */
	private static void welcomeMessage() {
		System.out.println("Welcome to Battleship");
		System.out.println("Your goal is to sink all ten ships in as few shots as possible.");
		System.out.println("The board is 10 x 10, containing one Battleship of size 4,");
		System.out.println("two Cruisers of size 3, three Destroyers of size 2, and");
		System.out.println("four Submarines of size 1.");
		System.out.println("Input Coordinates between 0-9, inclusive, to choose a ");
		System.out.println("destination to fire on.");		
	}
	
	
			
		
	
	


}
