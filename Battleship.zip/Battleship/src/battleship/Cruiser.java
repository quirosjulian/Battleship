package battleship;

public class Cruiser extends Ship {
	
	/**
	 * Sets the length of a Cruiser ship to 3. 
	 */
	public Cruiser() {
		this.length = 3;
		for (int i = 0; i < length; i++) {
			hit[i] = false;
		}
		
	}
	
	/* (non-Javadoc)
	 * @see battleship.Ship#getShipType()
	 */
	@Override
	String getShipType() {
		return "Cruiser";
		
	}
	

	/* (non-Javadoc)
	 * @see battleship.Ship#getLength()
	 */
	@Override
	int getLength() {
		return 3;
	}

}
