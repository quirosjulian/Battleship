package battleship;

import java.util.Random;


public class Ocean {
	Ship[][] ships = new Ship[10][10];
	int shotsFired;
	int hitCount;
	boolean spotTaken;
	int titanic;
	
	/**
	 * Creates a new 10 x 10 board, fills it with EmptySea objects, and resets Shots Fired
	 * and Hit Count to 0. 
	 */
	public Ocean() {
		this.ships = new Ship[10][10];
		int shotsFired = 0;
		int hitCount = 0;
		for (int i = 0; i < ships.length; i++) {
			for (int j = 0; j < ships.length; j++){
				ships[i][j] = new EmptySea();
			}
		}
		
	}
	
	/**
	 * Places all 10 ships randomly across the board. Begins by placing a Battleship
	 * and descends by length. 
	 */
	void placeAllShipsRandomly() {
		/* Start with battleship, go down by length, while i< 1, generate random for
		 * int row, col, and boo hor, instantiate a battleship object using row col and
		 * hor, call okToPlaceShipAt, if true place ship on board and increase i. 
		 * Otherwise do not increase i and do not put on board, end of while. After
		 * all ships fill empty spaces with emptySea object, with nested for loop.
		 */
		Random rand = new Random();
		
		int i = 0;
		while (i < 1) {
			int rand_row = rand.nextInt(10);
			int rand_col = rand.nextInt(10);
			boolean rand_hor = rand.nextBoolean();
			Battleship battleship = new Battleship();
			if (battleship.okToPlaceShipAt(rand_row, rand_col, rand_hor, this)) {
				battleship.placeShipAt(rand_row, rand_col, rand_hor, this);
				i++;
			}
		}
		i = 0;
		while (i < 2) {
			int rand_row = rand.nextInt(10);
			int rand_col = rand.nextInt(10);
			boolean rand_hor = rand.nextBoolean();
			Cruiser cruiser = new Cruiser();
			if (cruiser.okToPlaceShipAt(rand_row, rand_col, rand_hor, this)) {
				cruiser.placeShipAt(rand_row, rand_col, rand_hor, this);
				i++;
			}	
			
		}
		i = 0;
		while (i < 3) {
			int rand_row = rand.nextInt(10);
			int rand_col = rand.nextInt(10);
			boolean rand_hor = rand.nextBoolean();
			Destroyer destroyer = new Destroyer();
			if (destroyer.okToPlaceShipAt(rand_row, rand_col, rand_hor, this)) {
				destroyer.placeShipAt(rand_row, rand_col, rand_hor, this);
				i++;
			}
		}
		i = 0;
		while (i < 4) {
			int rand_row = rand.nextInt(10);
			int rand_col = rand.nextInt(10);
			boolean rand_hor = rand.nextBoolean();
			Submarine submarine = new Submarine();
			if (submarine.okToPlaceShipAt(rand_row, rand_col, rand_hor, this)) {
				submarine.placeShipAt(rand_row, rand_col, rand_hor, this);
				i++;
			}
		}
		
	}
	
	/**
	 * Returns true if a space on the board is occupied, or false if it is occupied by
	 * an Empty Sea. 
	 * @param row
	 * @param column
	 * @return spotTaken 
	 */
	public boolean isOccupied(int row, int column) {
		/* True if given location contains a ship, false if not.
		 * 
		 */
		if (ships[row][column].getShipType().equals("Empty Sea")) {
			spotTaken = false;
		}
		else {
			spotTaken = true;
		}
		return spotTaken;
	}
	
	/**
	 * Increments the total shots fired count by one, and increments the hit count if 
	 * the location shot at contains a floating ship. Also increments the count of 
	 * ships sunken if ship is sunk. 
	 * @param row
	 * @param column
	 * @return True or False
	 */
	boolean shootAt(int row, int column) {
		/* Returns true if the given location contains a real ship, still afloat, false
		 * if not. Method also updates the number of shots fired and number of hits. 
		 * If location contains a real ship should return true every time user shoots at
		 * same location. Only once it has been sunk should it return false.
		 */
		shotsFired += 1;
		if (ships[row][column].getShipType() != "Empty Sea") {
			hitCount += 1;
		}
		if (ships[row][column].shootAt(row, column) && ships[row][column].isSunk()) {
			titanic++;
			return true;
		}
		else if (ships[row][column].shootAt(row, column)) {
			return true;
		}
		else {
			return false;
		}

	}
	
	/**
	 * Returns the count of the number of shots fired. 
	 * @return shotsFired
	 */
	int getShotsFired() {
		return shotsFired;
		
	}
	
	/**
	 * Returns the amount of direct hits.
	 * @return hitCount
	 */
	int getHitCount() {
		/* returns the number of hits recorded, all hits counted not just the first time
		 * a square is hit. Allow user to get a worse score if hit the same location.  
		 */
		return hitCount;
	}
	
	/**
	 * Returns how many ships have been sunk.
	 * @return titanic
	 */
	int sunkenShips() {
		return titanic;
	}
	/**
	 * Returns true if all 10 ships have been sunk
	 * @return
	 */
	boolean isGameOver() {
		// true if all ships sunk
		if (titanic == 10) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Returns the updated Array of Ships
	 * @return
	 */
	Ship[][] getShipArray() {
		/* Returns actual 10x10 array, not a copy 
		 * 
		 */
		return ships;
	}
	
	/**
	 * Prints the ocean, with row and column numbers labeled. 'S' indicates a part
	 * of a ship hit, '-' for fired upon and empty sea, 'x' for a sunken ship, and
	 * '.' for not fired upon. 
	 */
	void print() {
		/* Prints the ocean, to aid user row numbers along left edge, column along top.
		 * 0-9, S to indicate a location fired upon and hit a part of ship, - for fired
		 * and hit nothing, x for sunken ship, . for not fired upon. 
		 */
		System.out.println("  0  1  2  3  4  5  6  7  8  9");
		System.out.println("  ----------------------------");
		for (int i = 0; i < 10; i++) {
			System.out.print(String.valueOf(i) + "|");
			for (int j = 0; j < 10; j++) {
				if (! getShipArray()[i][j].getShipType().equals("Empty Sea")) {
					if (getShipArray()[i][j].isHorizontal()) {
						if (! getShipArray()[i][j].isSunk() && getShipArray()[i][j].hit[j - getShipArray()[i][j].bowColumn]) {
							System.out.print("S  ");
						}
						else if (getShipArray()[i][j].isSunk()) {
							System.out.print("x  ");
						}
						else {
							System.out.print("-  ");
						}
					}
					else {
						if (! getShipArray()[i][j].isSunk() && getShipArray()[i][j].hit[i - getShipArray()[i][j].bowRow]) {
							System.out.print("S  ");
						}
						else if (getShipArray()[i][j].isSunk()) {
							System.out.print("x  ");
						}
						else {
							System.out.print("-  ");
						}
					}
				}
				else {
					System.out.print(".  ");
				}
			}
			System.out.println();	
		}
		
	}

}
