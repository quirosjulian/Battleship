package battleship;

import static org.junit.Assert.*;

import org.junit.Test;

public class OceanTest {
	
	Ocean O = new Ocean();
	Ship[][] s = O.ships; 
	Battleship battleship = new Battleship();
	Cruiser cruiser = new Cruiser();
	Destroyer destroyer = new Destroyer();
	Submarine submarine = new Submarine();
	EmptySea emptysea = new EmptySea();


	@Test
	public void testOcean() {
		
		assertEquals(O.ships.length, 10);
	}

	@Test
	public void testPlaceAllShipsRandomly() {
		O.placeAllShipsRandomly();
		int numOfBattleShips = 0;
		int numOfCruisers = 0;
		int numOfDest = 0;
		int numOfSub = 0;
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if (O.ships[i][j].getShipType() == "Battleship") {
					numOfBattleShips += 1;
				}else if (O.ships[i][j].getShipType() == "Cruiser") {
					numOfCruisers += 1;
				}else if (O.ships[i][j].getShipType() == "Destroyer") {
					numOfDest += 1;
				} else if (O.ships[i][j].getShipType() == "Submarine") {
					numOfSub += 1;
				}
			}
		}
		assertEquals(4, numOfBattleShips);
		assertEquals(6, numOfCruisers);
		assertEquals(6, numOfDest);
		assertEquals(4, numOfSub);
	}

	@Test
	public void testIsOccupied() {
		battleship.placeShipAt(1, 5, false, O);
		assertTrue(O.isOccupied(1, 5));
		assertFalse(O.isOccupied(1, 6));
		assertTrue(O.isOccupied(2, 5));
		
	}

	@Test
	public void testShootAt() {
		battleship.placeShipAt(1, 5, false, O);
		assertTrue(O.shootAt(1, 5));
		assertTrue(O.shootAt(2, 5));
		assertFalse(O.shootAt(1, 6));
		assertEquals(2, O.hitCount);
		assertEquals(3, O.shotsFired);
		assertTrue(O.shootAt(1, 5));
		assertTrue(O.shootAt(2, 5));
		assertTrue(O.shootAt(3, 5));
		assertTrue(O.shootAt(4, 5));
		assertFalse(O.shootAt(1, 5));
	}

	@Test
	public void testGetShotsFired() {
		battleship.placeShipAt(1, 5, false, O);
		O.shootAt(1, 5);
		O.shootAt(2, 5);
		O.shootAt(3, 5);
		O.shootAt(4, 5);
		assertEquals(4, O.shotsFired);
	}

	@Test
	public void testGetHitCount() {
		battleship.placeShipAt(1, 5, false, O);
		O.shootAt(1, 5);
		O.shootAt(1, 6);
		O.shootAt(2, 5);
		assertEquals(2, O.getHitCount());
		O.shootAt(3, 5);
		O.shootAt(4, 5);
		assertEquals(4, O.getHitCount());
		
	}

	@Test
	public void testIsGameOver() {
		Submarine sub1 = new Submarine();
		Submarine sub2 = new Submarine();
		Submarine sub3 = new Submarine();
		Submarine sub4 = new Submarine();
		Submarine sub5 = new Submarine();
		Submarine sub6 = new Submarine();
		Submarine sub7 = new Submarine();
		Submarine sub8 = new Submarine();
		Submarine sub9 = new Submarine();
		Submarine sub10 = new Submarine();
		sub1.placeShipAt(0, 0, false, O);
		sub2.placeShipAt(0, 1, false, O);
		sub3.placeShipAt(0, 2, false, O);
		sub4.placeShipAt(0, 3, false, O);
		sub5.placeShipAt(0, 4, false, O);
		sub6.placeShipAt(0, 5, false, O);
		sub7.placeShipAt(0, 6, false, O);
		sub8.placeShipAt(0, 7, false, O);
		sub9.placeShipAt(0, 8, false, O);
		sub10.placeShipAt(0, 9, false, O);
		O.shootAt(0, 0);
		O.shootAt(0, 1);
		O.shootAt(0, 2);
		O.shootAt(0, 3);
		O.shootAt(0, 4);
		O.shootAt(0, 5);
		O.shootAt(0, 6);
		O.shootAt(0, 7);
		O.shootAt(0, 8);
		O.shootAt(0, 9);
		assertEquals(10, O.sunkenShips());
		assertEquals(true, O.isGameOver());
		
		
		
	}

	@Test
	public void testGetShipArray() {
		battleship.placeShipAt(1, 5, false, O);
		assertEquals("Battleship", O.getShipArray()[1][5].getShipType());
	}

}
