package battleship;

public abstract class Ship {
	
	int bowRow; 
	int bowColumn;
	int length;
	boolean horizontal;
	boolean [] hit = new boolean[4];
	boolean withinBounds;
	boolean canPlaceShip;
			
	
	abstract int getLength();
		
		
	
// Getters
	
	/**
	 * Returns the Bow Row of a specific ship.
	 * @return bowRow
	 */
	public int getBowRow() {
		return this.bowRow;
		
	}
	
	/**
	 * Returns the Bow Column of a specific ship.
	 * @return bowColumn
	 */
	public int getBowColumn() {
		return this.bowColumn;
		
	}
	
	/**
	 * Returns True if ship is oriented horizontally. 
	 * @return horizontal
	 */
	public boolean isHorizontal() {
		return this.horizontal;
		
	}
// Setters
	
	/**
	 * Sets row equal to bowRow.
	 * @param row 
	 */
	public void setBowRow(int row) {
		this.bowRow = row;
	}
	
	/**
	 * Sets column equal to bowColumn. 
	 * @param column 
	 */
	public void setBowColumn(int column) {
		this.bowColumn = column;
	}
	
	/**
	 * Sets this.horizontal equal to a True or False value of
	 * ships orientation. 
	 * @param horizontal 
	 */
	public void setHorizontal(boolean horizontal) {
		this.horizontal = horizontal;
	}
	
	/**
	 * Returns a string of which ship type it is. 
	 * @return  
	 */
	abstract String getShipType();
	
	
	/**
	 * Checks to see if the ship is horizontal. 
	 * @param row
	 * @param column
	 * @param ocean
	 * @return
	 */
	private boolean checkIfHorizontal(int row, int column, Ocean ocean) {
		if (column + this.getLength() > 10) {
			return false;
		}
		for (int i = row - 1; i <= row + 1; i++){
			for (int j = column - 1; j <= column + this.getLength(); j++) {
				if (i >= 0 && i < 10 && j >= 0 && j < 10 ) {
					if (ocean.isOccupied(i, j)) {
						return false;
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * Checks to see if ship is vertical.
	 * @param row
	 * @param column
	 * @param ocean
	 * @return
	 */
	private boolean checkIfVertical(int row, int column, Ocean ocean) {
		if (row + this.getLength() > 10) {
			return false;
		}
		for (int i = row - 1; i <= row +this.getLength(); i++) {
			for (int j = column - 1; j <= column + 1; j++) {
				if (i >= 0 && i < 10 && j >= 0 && j < 10) {
					if (ocean.isOccupied(i, j)) {
					return false;
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * Checks to see if it is ok to place a ship at a certain location in the array.
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 * @return
	 */
	public boolean okToPlaceShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		if (row < 0 || row >= 10 || column < 0 || column >= 10) {
			return false;
		}
		if (horizontal == true) {
			return checkIfHorizontal(row, column, ocean);
		}
		else {
			return checkIfVertical(row, column, ocean);
		}
	}
	
	/**
	 * Places ship at a certain location if legal. 
	 * @param row
	 * @param column
	 * @param horizontal
	 * @param ocean
	 */
	void placeShipAt(int row, int column, boolean horizontal, Ocean ocean) {
		setBowRow(row);
		setBowColumn(column);
		setHorizontal(horizontal);
		Ship[][] ships = ocean.getShipArray();
		for (int i = 0; i < length; i++) {
			if (horizontal) {
				ships[row][column + i] = this;
			}
		
			else {
				ships[row + i][column] = this;
			}
		}
	}
	
	/**
	 * Marks a part of a ship as hit if shot at and has not been sunk.
	 * @param row
	 * @param column
	 * @return
	 */
	boolean shootAt(int row, int column) {
		if (this.horizontal) {
			int boom = 0;
			for (int i = 0; i < length; i++) {
				int rowHead = bowRow;
				int columnHead = i + bowColumn;
				if (row == rowHead && column == columnHead) {
					if (isSunk() == false) {
						boom += 1;
					}
					hit[i] = true;
				}
			}
			if (boom > 0) {
				return true;
		}
			else {
				return false;
		}
	}
	else {
		int boom = 0;
		for (int i = 0; i < length; i++) {
			int rowHead = i + bowRow;
			int columnHead = bowColumn;
			if (row == rowHead && column == columnHead) {
				if (isSunk() == false) {
					boom += 1;
				}
				hit[i] = true;
			}
		}
		if (boom > 0) {
			return true;
		}
		else {
			return false;
		}
	}
	}
	
	/**
	 * Returns true if every space for a ship has been hit. 
	 * @return
	 */
	boolean isSunk() {
		for (int i = 0; i < length; i++) {
			if (this.hit[i] == false) {
				return false;
			}
		}
		return true;
		
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		if (isSunk()) {
			return "x";
		}
		else {
			return "S";
		}
		
	}

}
