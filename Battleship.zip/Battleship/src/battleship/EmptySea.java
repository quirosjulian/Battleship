package battleship;

public class EmptySea extends Ship{
	
	/**
	 * Sets the rest of the board that is not occupied by a Ship to an Empty Sea object
	 * of length 1. 
	 */
	public EmptySea(){
		int length = 1;
	}
	
	/* (non-Javadoc)
	 * @see battleship.Ship#shootAt(int, int)
	 */
	@Override
	boolean shootAt(int row, int column) {
		return false;
	}
	
	/* (non-Javadoc)
	 * @see battleship.Ship#isSunk()
	 */
	@Override
	boolean isSunk() {
		return false;
	}
	
	/* (non-Javadoc)
	 * @see battleship.Ship#toString()
	 */
	@Override
	public String toString() {
		return "-";
	}

	/* (non-Javadoc)
	 * @see battleship.Ship#getLength()
	 */
	@Override
	int getLength() {
		return this.length;
	}

	/* (non-Javadoc)
	 * @see battleship.Ship#getShipType()
	 */
	@Override
	String getShipType() {
		return "Empty Sea";
	}
	
	

}
