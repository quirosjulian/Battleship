package battleship;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShipTest {
	
	Ocean O = new Ocean();
	Ship[][] s = O.ships;
	Battleship battleship = new Battleship();
	Cruiser cruiser = new Cruiser();
	Destroyer destroyer = new Destroyer();
	Submarine submarine = new Submarine();
	EmptySea emptysea = new EmptySea();

	@Test
	public void testGetLength() {
		assertEquals(4, battleship.getLength());
		assertEquals(3, cruiser.getLength());
		assertEquals(2, destroyer.getLength());
		assertEquals(1, submarine.getLength());
	}

	@Test
	public void testGetBowRow() {
		battleship.setBowRow(2);
		assertEquals(2, battleship.getBowRow());
		cruiser.setBowRow(3);
		assertEquals(3, cruiser.getBowRow());
		destroyer.setBowRow(4);
		assertEquals(4, destroyer.getBowRow());
		submarine.setBowRow(1);
		assertEquals(1, submarine.getBowRow());
	}

	@Test
	public void testGetBowColumn() {
		battleship.setBowColumn(2);
		assertEquals(2, battleship.getBowColumn());
		cruiser.setBowColumn(3);
		assertEquals(3, cruiser.getBowColumn());
		destroyer.setBowColumn(5);
		assertEquals(5, destroyer.getBowColumn());
		submarine.setBowColumn(6);
		assertEquals(6, submarine.getBowColumn());
	}

	@Test
	public void testIsHorizontal() {
		battleship.setHorizontal(false);
		assertFalse(battleship.isHorizontal());
		cruiser.setHorizontal(true);
		assertTrue(cruiser.isHorizontal());
		destroyer.setHorizontal(false);
		assertFalse(destroyer.isHorizontal());
		submarine.setHorizontal(true);
		assertTrue(submarine.isHorizontal());
	}

	@Test
	public void testSetBowRow() {
		battleship.setBowRow(2);
		assertEquals(2, battleship.getBowRow());
		cruiser.setBowRow(3);
		assertEquals(3, cruiser.getBowRow());
		destroyer.setBowRow(4);
		assertEquals(4, destroyer.getBowRow());
		submarine.setBowRow(1);
		assertEquals(1, submarine.getBowRow());
		
	}

	@Test
	public void testSetBowColumn() {
		battleship.setBowColumn(2);
		assertEquals(2, battleship.getBowColumn());
		cruiser.setBowColumn(3);
		assertEquals(3, cruiser.getBowColumn());
		destroyer.setBowColumn(5);
		assertEquals(5, destroyer.getBowColumn());
		submarine.setBowColumn(6);
		assertEquals(6, submarine.getBowColumn());
	}

	@Test
	public void testSetHorizontal() {
		battleship.setHorizontal(false);
		assertFalse(battleship.isHorizontal());
		cruiser.setHorizontal(true);
		assertTrue(cruiser.isHorizontal());
		destroyer.setHorizontal(false);
		assertFalse(destroyer.isHorizontal());
		submarine.setHorizontal(true);
		assertTrue(submarine.isHorizontal());
	}

	@Test
	public void testGetShipType() {
		assertEquals("Battleship", battleship.getShipType());
		assertEquals("Cruiser", cruiser.getShipType());
		assertEquals("Empty Sea", emptysea.getShipType());
		assertEquals("Destroyer", destroyer.getShipType());
		assertEquals("Submarine", submarine.getShipType());
	}

	@Test
	public void testOkToPlaceShipAt() {
		assertTrue(battleship.okToPlaceShipAt(1, 3, true, O));
	}

	@Test
	public void testPlaceShipAt() {
		battleship.placeShipAt(6, 9, false, O);
		assertEquals(4, O.getShipArray()[6][9].getLength());
		assertFalse(O.getShipArray()[6][9].isHorizontal());
	}

	@Test
	public void testShootAt() {
		battleship.placeShipAt(5, 8, false, O);
		assertFalse(battleship.shootAt(4, 7));
		battleship.shootAt(7, 8);
		assertTrue(battleship.hit[2]);
		
	}

	@Test
	public void testIsSunk() {
		battleship.placeShipAt(5, 8, false, O);
		battleship.shootAt(7, 8);
		battleship.shootAt(6, 8);
		assertFalse(battleship.isSunk());
		battleship.shootAt(5, 8);
		battleship.shootAt(8, 8);
		assertTrue(battleship.isSunk());
		
	}

	@Test
	public void testToString() {
		assertEquals("-", emptysea.toString());
		battleship.placeShipAt(5, 8, false, O);
		battleship.shootAt(7, 8);
		battleship.shootAt(6, 8);
		assertEquals("S", battleship.toString());
		battleship.shootAt(5, 8);
		battleship.shootAt(8, 8);
		assertEquals("x", battleship.toString());
	}

}
